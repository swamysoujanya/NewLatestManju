﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AviMa.AviMaForms
{
    public partial class frmInvoice : Form
    {
        public frmInvoice()
        {
            InitializeComponent();
        }

        private void dtGridInvoice_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int rowNumber = e.RowIndex;

            if (rowNumber != -1 && String.IsNullOrEmpty(Convert.ToString(dtGridInvoice[0, rowNumber].Value)))
            {
                int intSiNo = 1 + rowNumber;
                dtGridInvoice[0, rowNumber].Value = intSiNo;
                dtGridInvoice[6, rowNumber].Value = "Delete";

            }
        }
    }
}
